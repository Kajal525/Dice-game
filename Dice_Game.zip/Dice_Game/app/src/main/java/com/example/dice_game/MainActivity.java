package com.example.dice_game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView userRoll, computer_roll;
    Button high_btn, low_btn;

    ImageView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userRoll = findViewById(R.id.user_die);
        computer_roll = findViewById(R.id.computer_die);

        high_btn = findViewById(R.id.higherButtonId);
        low_btn = findViewById(R.id.lowerButtonId);

        resultView = findViewById(R.id.imgResult);

        int[] array_die = {R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};

        int [] display_image = { R.drawable.computer_wins,
                                R.drawable.user_wins,
                                R.drawable.tie };

        high_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int user_random_roll = random_dir_generator();
                int computer_random_roll = random_dir_generator();

                userRoll.setImageResource(array_die[user_random_roll]);
                computer_roll.setImageResource(array_die[computer_random_roll]);

                resultView.setImageResource(display_image[winner_func(user_random_roll, computer_random_roll, "higher")]);
            }
        });

        low_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int user_random_roll = random_dir_generator();
                int computer_random_roll = random_dir_generator();

                userRoll.setImageResource(array_die[user_random_roll]);
                computer_roll.setImageResource(array_die[computer_random_roll]);

                resultView.setImageResource(display_image[winner_func(user_random_roll, computer_random_roll, "")]);
            }
        });
    }

    public int random_dir_generator() {
        Random random_roll = new Random();
        return random_roll.nextInt(6);
    }

    public int winner_func ( int user , int computer, String inputText) {
        int index_find = 0;
        if ( inputText.equals("higher")) { // Higher
            if (user > computer) {
                index_find = 1;
            } else if (user < computer) {
                index_find = 0;
            } else {
                index_find = 2;
            }
        } else { // Lower
            if (user < computer) {
                index_find = 1;
            } else if (user > computer) {
                index_find = 0;
            } else {
                index_find = 2;
            }
        }
        return index_find;
    }
}